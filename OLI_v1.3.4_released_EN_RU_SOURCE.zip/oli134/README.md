# OLI v1.0

Local AI assistant built around llama.cpp + GGUF.

Target PC:
- Windows 10
- NVIDIA GTX 1660 Super 6 GB
- Intel i7-2600K
- 8 GB RAM

Modules:
- OLI.Client: WPF chat UI
- OLI.Engine: C++ HTTP bridge to llama.cpp server
- OLI.Core: shared DTO/config
- OLI.Web: web-search provider abstraction
- OLI.Memory: local JSON memory
- OLI.Training: JSONL dataset manager

## Architecture

WPF -> OLI.Engine (localhost) -> llama.cpp server -> GGUF model

Web search and memory are tools used by the client/orchestrator.

## Important

This is a runnable starter skeleton, not a trained model. You do NOT need to manually download the GGUF. `scripts/start-llama.ps1` uses llama.cpp's `-hf` option and downloads the configured GGUF automatically on first launch.
The default target is Llama 3.2 3B Instruct Q4_K_M.

## Build

1. Install .NET 8 SDK and Visual Studio 2022 with Desktop C++.
2. Build llama.cpp with CUDA (or use an official prebuilt CUDA release).
3. Run `scripts/start-llama.ps1`. On first launch the model is downloaded automatically.
4. Run `scripts/start-oli.ps1`.
5. Run:
   `dotnet run --project OLI.Client`

If your CUDA build uses a different llama-server path, edit the script.

## Web search

The provider is DuckDuckGo HTML search, restricted to an allow-list of sites (Wikipedia, Ozon, DNS, Citilink, Yandex Market, Wildberries, M.Video, Habr, GitHub, Stack Overflow by default). The allow-list is enforced twice: as a `site:` filter on the query, and again by dropping any result whose host isn't on the list — so OLI can never end up citing an arbitrary site.

OLI does **not** search on every message. The system prompt tells the model to answer directly when it already knows enough, and to search only when it's missing information or needs to verify something that could be outdated (price, availability, a fast-moving fact). To request a search, the model must reply with a single `OLI_SEARCH: <query>` line; the client detects that, runs the restricted search, feeds the results back, and only then shows the final answer. If it never emits that line, no network request happens at all.

The gear (⚙) button in the chat header opens a settings popup with a master "allow search" toggle and a checkbox per site — changes apply to the very next message, no restart needed.

## Training

`OLI.Training` creates JSONL instruction examples. It does NOT fine-tune the base model by itself.
Use the generated JSONL with a LoRA/QLoRA training pipeline on a machine with sufficient VRAM/RAM.


## OLI v1.0.1 first-run model download

The launcher uses llama.cpp's native Hugging Face download option:

`-hf hugging-quants/Llama-3.2-3B-Instruct-Q4_K_M-GGUF:Q4_K_M`

This means the model does not have to be manually downloaded from a browser. The first launch requires an Internet connection and enough free disk space; subsequent launches reuse the local cache/files.


## v1.1 automatic runtime setup

Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\start-oli.ps1
```

The setup script:
1. Detects NVIDIA hardware/driver.
2. Ensures Git/CMake are available.
3. Downloads the latest Windows x64 CUDA llama.cpp release asset when available.
4. Installs `llama-server.exe` and its DLLs into the OLI folder.
5. Does not require the full CUDA Toolkit when using the prebuilt CUDA runtime.
6. Starts llama-server.
7. On first model launch, llama.cpp downloads the configured GGUF through `-hf`.

This follows the current llama.cpp Windows guidance: NVIDIA users can use a CUDA x64 release package, while source builds require the CUDA Toolkit and `GGML_CUDA=ON`. See the official documentation for details.

## v1.1.4 one-click install + OLI.exe

The easiest path from a clean machine to a working app:

```powershell
powershell -ExecutionPolicy Bypass -File .\Install-OLI.ps1
```

`Install-OLI.ps1` does everything in one run:
1. Checks for the .NET 8 SDK and installs it (via `winget`, or the official `dotnet-install.ps1`) if it's missing.
2. Runs `scripts\install-oli.ps1` to fetch the CUDA build of `llama-server.exe`.
3. Runs `scripts\build-oli.ps1`, which publishes a self-contained, single-file `dist\OLI.exe` — the target machine does not need the .NET runtime installed separately.
4. Creates an `OLI` shortcut on the Desktop and in the Start Menu that starts `llama-server` and then launches `OLI.exe`.

After that, just double-click the **OLI** shortcut.

### Building only the exe

If the llama.cpp engine is already installed and you only changed the app code:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build-oli.ps1
```

This produces `dist\OLI.exe`. `scripts\start-oli.ps1` (and the `OLI.bat` launcher created by `Install-OLI.ps1`) will use it automatically if present, and fall back to `dotnet run` for a dev machine where the exe hasn't been built yet.

## 1.3.1_released.1_released
- Persistent data is stored in `%LOCALAPPDATA%\\OLI`, separate from the installation directory.
- Context limiting prevents unbounded history growth.
- Added `🖥 Консоль` with live engine/application logs.
- Added atomic JSON writes and corrupted-file backups.
- Settings for context/GPU layers/threads are consumed by `start-llama.ps1`.
- Memory records are structured and deduplicated.
- Mobile pairing tokens now expire and request sizes are limited.


## Updates

OLI 1.3.4_released can check the latest public GitHub Release automatically at startup or manually from Settings. Configure the repository URL under Settings → Updates.

## OLI 1.3.4 — English language support

The 1.3.4 release adds Russian/English UI localization and automatic system-language detection. The installer supports `-Language auto|ru|en`.
