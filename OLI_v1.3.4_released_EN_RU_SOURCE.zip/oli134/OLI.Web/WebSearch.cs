using System.Net;
using System.Text.RegularExpressions;
using OLI.Core;

namespace OLI.Web;

/// <summary>
/// Thrown when a web search or page fetch could not be completed (network error,
/// blocked request, disallowed host, unexpected response, etc). Callers should
/// catch this and degrade gracefully instead of failing the whole chat turn.
/// </summary>
public sealed class WebSearchException(string message, Exception? inner = null)
    : Exception(message, inner);

public sealed class WebSearch
{
    private readonly HttpClient _http;

    private static readonly Regex ResultBlockRx = new(
        @"<div class=""result[^""]*""[^>]*>(?<block>.*?)<div class=""clear""",
        RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);

    private static readonly Regex TitleRx = new(
        @"<a[^>]*class=""result__a""[^>]*href=""(?<href>[^""]+)""[^>]*>(?<title>.*?)</a>",
        RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);

    private static readonly Regex SnippetRx = new(
        @"<a[^>]*class=""result__snippet""[^>]*>(?<snippet>.*?)</a>",
        RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);

    private static readonly Regex TagRx = new("<.*?>", RegexOptions.Singleline | RegexOptions.Compiled);

    private static readonly Regex ScriptOrStyleRx = new(
        @"<(script|style|noscript)\b[^>]*>.*?</\1>",
        RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);

    private static readonly Regex WhitespaceRx = new(@"[ \t]*\r?\n[ \t]*", RegexOptions.Compiled);
    private static readonly Regex MultiSpaceRx = new(@"[ \t]{2,}", RegexOptions.Compiled);

    public WebSearch()
    {
        _http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
        _http.DefaultRequestHeaders.UserAgent.ParseAdd(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 OLI/1.3");
    }

    /// <summary>
    /// Runs a DuckDuckGo HTML search restricted to <paramref name="allowedDomains"/> and
    /// returns up to <paramref name="limit"/> results, each with a title, resolved
    /// destination URL and a text snippet. Results whose host isn't one of the allowed
    /// domains (or a subdomain of one) are dropped even if DuckDuckGo's site: filter
    /// somehow lets them through, so the allow-list is enforced defensively, not just
    /// requested via the query.
    /// </summary>
    public async Task<List<SearchResult>> SearchAsync(
        string query,
        IReadOnlyList<string> allowedDomains,
        int limit = 5,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(query)) return [];
        if (allowedDomains.Count == 0) return [];

        var siteFilter = string.Join(" OR ", allowedDomains.Select(d => $"site:{d}"));
        var fullQuery = $"{query} ({siteFilter})";
        var url = "https://html.duckduckgo.com/html/?q=" + Uri.EscapeDataString(fullQuery);

        string html;
        try
        {
            using var response = await _http.GetAsync(url, ct);
            response.EnsureSuccessStatusCode();
            html = await response.Content.ReadAsStringAsync(ct);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            throw new WebSearchException("Поиск занял слишком много времени.");
        }
        catch (HttpRequestException ex)
        {
            throw new WebSearchException($"Не удалось обратиться к поисковику: {ex.Message}", ex);
        }

        var results = new List<SearchResult>();

        foreach (Match block in ResultBlockRx.Matches(html))
        {
            if (results.Count >= limit) break;

            var blockHtml = block.Groups["block"].Value;

            var titleMatch = TitleRx.Match(blockHtml);
            if (!titleMatch.Success) continue;

            var title = CleanText(titleMatch.Groups["title"].Value);
            var link = ResolveResultUrl(titleMatch.Groups["href"].Value);
            if (title.Length == 0 || link.Length == 0) continue;

            // Enforce the allow-list ourselves — never trust the query filter alone.
            if (!IsAllowedHost(link, allowedDomains)) continue;

            var snippetMatch = SnippetRx.Match(blockHtml);
            var snippet = snippetMatch.Success ? CleanText(snippetMatch.Groups["snippet"].Value) : "";

            results.Add(new SearchResult(title, link, snippet));
        }

        return results;
    }

    /// <summary>
    /// Fetches a single page and returns its readable text (scripts/styles/tags
    /// stripped, whitespace collapsed), truncated to <paramref name="maxChars"/>.
    /// Only allowed-domain URLs can be fetched — this is enforced here, not just
    /// left to the caller, since the model itself chooses which URL to open.
    /// </summary>
    public async Task<string> FetchPageTextAsync(
        string url,
        IReadOnlyList<string> allowedDomains,
        int maxChars = 2000,
        CancellationToken ct = default)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
        {
            throw new WebSearchException("Некорректная ссылка.");
        }

        if (!IsAllowedHost(url, allowedDomains))
        {
            throw new WebSearchException("Эта страница не входит в список разрешённых сайтов.");
        }

        string html;
        try
        {
            using var response = await _http.GetAsync(uri, ct);
            response.EnsureSuccessStatusCode();
            html = await response.Content.ReadAsStringAsync(ct);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            throw new WebSearchException("Загрузка страницы заняла слишком много времени.");
        }
        catch (HttpRequestException ex)
        {
            throw new WebSearchException($"Не удалось открыть страницу: {ex.Message}", ex);
        }

        var text = ExtractReadableText(html);
        if (text.Length > maxChars) text = text[..maxChars] + " …[обрезано]";
        return text;
    }

    private static bool IsAllowedHost(string url, IReadOnlyList<string> allowedDomains)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return false;
        var host = uri.Host.ToLowerInvariant();

        foreach (var domain in allowedDomains)
        {
            var d = domain.Trim().ToLowerInvariant();
            if (d.Length == 0) continue;
            if (host == d || host.EndsWith("." + d, StringComparison.Ordinal)) return true;
        }

        return false;
    }

    /// <summary>
    /// DuckDuckGo's HTML results wrap every link in a redirect
    /// (//duckduckgo.com/l/?uddg=&lt;encoded target&gt;&amp;rut=...). Extract and
    /// decode the real target so OLI shows/cites/opens the actual source, not a DDG
    /// redirect, and so the allow-list check above sees the real destination host.
    /// </summary>
    private static string ResolveResultUrl(string rawHref)
    {
        var href = WebUtility.HtmlDecode(rawHref);

        var idx = href.IndexOf("uddg=", StringComparison.OrdinalIgnoreCase);
        if (idx >= 0)
        {
            var start = idx + "uddg=".Length;
            var end = href.IndexOf('&', start);
            var encoded = end >= 0 ? href[start..end] : href[start..];
            try
            {
                return Uri.UnescapeDataString(encoded);
            }
            catch (UriFormatException)
            {
                // fall through and return the raw href below
            }
        }

        if (href.StartsWith("//", StringComparison.Ordinal)) return "https:" + href;
        return href;
    }

    private static string CleanText(string rawHtml)
    {
        var noTags = TagRx.Replace(rawHtml, "");
        return WebUtility.HtmlDecode(noTags).Trim();
    }

    private static string ExtractReadableText(string html)
    {
        var noScripts = ScriptOrStyleRx.Replace(html, " ");
        var noTags = TagRx.Replace(noScripts, " ");
        var decoded = WebUtility.HtmlDecode(noTags);
        var noNewlines = WhitespaceRx.Replace(decoded, " ");
        return MultiSpaceRx.Replace(noNewlines, " ").Trim();
    }
}
