namespace OLI.Core;

/// <summary>
/// A single site OLI is allowed to pull web-search results from.
/// IsEnabled is toggled live from the chat UI's search-settings panel.
/// </summary>
public sealed class AllowedSite(string name, string domain, bool isEnabled = true)
{
    public string Name { get; set; } = name;
    public string Domain { get; set; } = domain;
    public bool IsEnabled { get; set; } = isEnabled;
}

/// <summary>
/// Default curated allow-list: general reference plus the most common
/// RU retail/tech sites, so OLI can look up things like prices,
/// specs and availability without being able to browse the open web.
/// </summary>
public static class DefaultAllowedSites
{
    public static List<AllowedSite> Create() =>
    [
        new AllowedSite("Википедия", "wikipedia.org"),
        new AllowedSite("Ozon", "ozon.ru"),
        new AllowedSite("DNS", "dns-shop.ru"),
        new AllowedSite("Ситилинк", "citilink.ru"),
        new AllowedSite("Яндекс.Маркет", "market.yandex.ru"),
        new AllowedSite("Wildberries", "wildberries.ru"),
        new AllowedSite("М.Видео", "mvideo.ru"),
        new AllowedSite("Habr", "habr.com"),
        new AllowedSite("GitHub", "github.com"),
        new AllowedSite("Stack Overflow", "stackoverflow.com"),
    ];
}
