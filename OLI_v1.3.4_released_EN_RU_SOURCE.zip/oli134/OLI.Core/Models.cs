using System.Text.Json.Serialization;

namespace OLI.Core;

public record ChatMessage(string Role, string Content);
public record ChatRequest(string Model, IReadOnlyList<ChatMessage> Messages, double Temperature = 0.7, int MaxTokens = 512);
public record ChatResponse(string Text);
public record SearchResult(string Title, string Url, string Snippet);

public enum GenerationMode { Fast, Performance }
public enum OliTheme { Dark, Light, System }

public enum OliLanguage { Auto, Russian, English }

public sealed class OliSettings
{
    public string LlamaBaseUrl { get; set; } = "http://127.0.0.1:8080";
    public string Model { get; set; } = "oli";
    public int MaxTokens { get; set; } = 512;
    public double Temperature { get; set; } = 0.7;
    public bool WebSearchEnabled { get; set; } = true;
    public int WebSearchResultLimit { get; set; } = 5;
    public GenerationMode Mode { get; set; } = GenerationMode.Fast;
    public OliTheme Theme { get; set; } = OliTheme.Dark;
    public int FastMaxTokens { get; set; } = 384;
    public int PerformanceMaxTokens { get; set; } = 1024;
    public int ContextSize { get; set; } = 4096;
    public int BatchSize { get; set; } = 128;
    public int UBatchSize { get; set; } = 64;
    public int Parallel { get; set; } = 1;
    public int CpuThreads { get; set; } = 8;
    public int GpuLayers { get; set; } = 99;
    public List<AllowedSite> AllowedSites { get; set; } = DefaultAllowedSites.Create();
    public bool CheckForUpdatesOnStartup { get; set; } = true;
    public string GitHubRepositoryUrl { get; set; } = "https://github.com/REPLACE_ME/OLI";
    public OliLanguage Language { get; set; } = OliLanguage.Auto;
}
