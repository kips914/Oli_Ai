using System.Net.Http.Json;
using System.Text.Json;
using OLI.Core;

namespace OLI.Engine;

public sealed class LlamaClient : IDisposable
{
    private readonly HttpClient _http;
    public string BaseUrl { get; }

    public LlamaClient(string baseUrl)
    {
        BaseUrl = baseUrl.TrimEnd('/');
        _http = new HttpClient { BaseAddress = new Uri(BaseUrl + "/"), Timeout = TimeSpan.FromMinutes(10) };
    }

    public async Task<string> ChatAsync(IReadOnlyList<ChatMessage> messages, string model, double temperature, int maxTokens, CancellationToken ct = default)
    {
        var body = new { model, messages, temperature, max_tokens = maxTokens, stream = false, cache_prompt = true };
        var sw = System.Diagnostics.Stopwatch.StartNew();
        using var response = await _http.PostAsJsonAsync("v1/chat/completions", body, ct);
        response.EnsureSuccessStatusCode();
        using var stream = await response.Content.ReadAsStreamAsync(ct);
        using var doc = await JsonDocument.ParseAsync(stream, cancellationToken: ct);
        var text = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString() ?? "";
        sw.Stop();
        OliLog.Info("ENGINE", $"Generation finished in {sw.Elapsed.TotalSeconds:F2}s, chars={text.Length}");
        return text;
    }

    public async Task<bool> IsAliveAsync(CancellationToken ct = default)
    {
        try { using var r = await _http.GetAsync("health", ct); return r.IsSuccessStatusCode; }
        catch { return false; }
    }

    public async Task<string?> GetPropsAsync(CancellationToken ct = default)
    {
        try
        {
            using var r = await _http.GetAsync("props", ct);
            if (!r.IsSuccessStatusCode) return null;
            return await r.Content.ReadAsStringAsync(ct);
        }
        catch { return null; }
    }

    public void Dispose() => _http.Dispose();
}
