﻿$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot

if (!(Test-Path (Join-Path $root "third_party\llama.cpp\build\bin\Release\llama-server.exe"))) {
    & "$PSScriptRoot\install-oli.ps1"
}

Start-Process powershell -WindowStyle Hidden -ArgumentList "-ExecutionPolicy Bypass -File `"$root\scripts\start-llama.ps1`""
Start-Sleep -Seconds 4

# Prefer the compiled, self-contained OLI.exe (built by build-oli.ps1 / Install-OLI.ps1).
# Falls back to `dotnet run` for development machines where OLI.exe hasn't been built yet.
$exe = Join-Path $root "dist\OLI.exe"

if (Test-Path $exe) {
    Start-Process $exe
} else {
    Write-Host "OLI.exe ещё не собран — запускаю через 'dotnet run' (dev-режим)."
    Write-Host "Чтобы собрать OLI.exe один раз, запустите scripts\build-oli.ps1"
    dotnet run --project "$root\OLI.Client\OLI.Client.csproj"
}
