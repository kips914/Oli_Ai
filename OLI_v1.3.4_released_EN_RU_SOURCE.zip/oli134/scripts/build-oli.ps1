param(
    [ValidateSet('auto','ru','en')]
    [string]$Language = 'auto'
)
$ErrorActionPreference = "Stop"

function Resolve-Language([string]$value) {
    if ($value -eq 'ru') { return 'ru' }
    if ($value -eq 'en') { return 'en' }
    $culture = [System.Globalization.CultureInfo]::CurrentUICulture.TwoLetterISOLanguageName
    return $(if ($culture -eq 'en') { 'en' } else { 'ru' })
}
$Language = Resolve-Language $Language

$Strings = @{
    ru = @{ Title='OLI 1.3.4_released - сборка OLI.exe'; Missing='.NET SDK не найден. Сначала запустите Install-OLI.ps1, либо установите .NET 8 SDK вручную.'; Publishing='Публикую самодостаточный (self-contained) OLI.exe для win-x64...'; Wait='Это может занять пару минут при первой сборке.'; Failed='Сборка не удалась. Смотрите вывод dotnet publish выше.'; Done='Готово'; MissingExe='OLI.exe не появился. Проверьте вывод сборки выше.' }
    en = @{ Title='OLI 1.3.4_released - building OLI.exe'; Missing='.NET SDK was not found. Run Install-OLI.ps1 first or install the .NET 8 SDK manually.'; Publishing='Publishing a self-contained OLI.exe for win-x64...'; Wait='The first build may take a couple of minutes.'; Failed='Build failed. See the dotnet publish output above.'; Done='Done'; MissingExe='OLI.exe was not produced. Check the build output above.' }
}
function T([string]$key) { return $Strings[$Language][$key] }

$root = Split-Path -Parent $PSScriptRoot
$project = Join-Path $root "OLI.Client\OLI.Client.csproj"
$publishDir = Join-Path $root "dist"
Write-Host "======================================"
Write-Host (T 'Title')
Write-Host "======================================"

if (!(Get-Command dotnet -ErrorAction SilentlyContinue)) { Write-Error (T 'Missing'); exit 1 }
Write-Host (T 'Publishing')
Write-Host (T 'Wait')
Write-Host ""

dotnet publish $project -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $publishDir
if ($LASTEXITCODE -ne 0) { Write-Error (T 'Failed'); exit 1 }

$exe = Join-Path $publishDir "OLI.exe"
if (Test-Path $exe) {
    Write-Host ""; Write-Host "======================================"; Write-Host "$(T 'Done'): $exe"; Write-Host "======================================"
} else { Write-Error "$(T 'MissingExe') Path: $publishDir"; exit 1 }
