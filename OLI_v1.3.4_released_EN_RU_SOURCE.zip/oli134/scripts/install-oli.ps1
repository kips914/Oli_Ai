param(
    [ValidateSet('auto','ru','en')]
    [string]$Language = 'auto'
)
$ErrorActionPreference = "Stop"

function Resolve-Language([string]$value) {
    if ($value -eq 'ru') { return 'ru' }
    if ($value -eq 'en') { return 'en' }
    $culture = [System.Globalization.CultureInfo]::CurrentUICulture.TwoLetterISOLanguageName
    return $(if ($culture -eq 'en') { 'en' } else { 'ru' })
}
$Language = Resolve-Language $Language

$Strings = @{
    ru = @{
        Title='OLI v1.3.4_released - установщик CUDA'; NoGpu='Видеокарта NVIDIA не обнаружена.'; Searching='Поиск совместимой Windows CUDA 12.4 x64 сборки llama.cpp...'; None='В последних 10 релизах не найдена совместимая Windows CUDA 12.4 x64 сборка llama.cpp.'; Selected='Выбран релиз'; Binary='Бинарник'; Runtime='Runtime'; DownloadBinary='Загрузка llama.cpp CUDA...'; DownloadRuntime='Загрузка CUDA runtime DLL...'; Missing='llama-server.exe не найден в загруженном архиве.'; Success='llama.cpp CUDA успешно установлена.'; Server='Сервер'; NoToolkit='Полная установка CUDA Toolkit не требуется для этого готового runtime.'; Driver='Используется установленный драйвер NVIDIA.'
    }
    en = @{
        Title='OLI v1.3.4_released - CUDA installer'; NoGpu='NVIDIA GPU was not detected.'; Searching='Searching for a compatible Windows CUDA 12.4 x64 llama.cpp build...'; None='No compatible Windows CUDA 12.4 x64 llama.cpp build was found in the last 10 releases.'; Selected='Selected release'; Binary='Binary'; Runtime='Runtime'; DownloadBinary='Downloading llama.cpp CUDA...'; DownloadRuntime='Downloading CUDA runtime DLLs...'; Missing='llama-server.exe was not found in the downloaded archive.'; Success='llama.cpp CUDA installed successfully.'; Server='Server'; NoToolkit='A full CUDA Toolkit installation is not required for this prebuilt runtime.'; Driver='The installed NVIDIA driver is used by this build.'
    }
}
function T([string]$key) { return $Strings[$Language][$key] }

$root = Split-Path -Parent $PSScriptRoot
$binDir = Join-Path $root "third_party\llama.cpp\build\bin\Release"
$server = Join-Path $binDir "llama-server.exe"

Write-Host "======================================"
Write-Host (T 'Title')
Write-Host "======================================"

$nvidia = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -match "NVIDIA" } | Select-Object -First 1
if (!$nvidia) { Write-Error (T 'NoGpu'); exit 1 }
Write-Host "GPU: $($nvidia.Name)"
Write-Host "Driver: $($nvidia.DriverVersion)"

$headers = @{ "User-Agent" = "OLI-v1.3.4" }
Write-Host (T 'Searching')
$releases = Invoke-RestMethod -Uri "https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=10" -Headers $headers

$binary = $null; $runtime = $null; $selectedRelease = $null
foreach ($release in $releases) {
    $candidate = $release.assets | Where-Object { $_.name -like "llama-b*-bin-win-cuda-12.4-x64.zip" } | Select-Object -First 1
    $candidateRuntime = $release.assets | Where-Object { $_.name -eq "cudart-llama-bin-win-cuda-12.4-x64.zip" } | Select-Object -First 1
    if ($candidate -and $candidateRuntime) { $binary = $candidate; $runtime = $candidateRuntime; $selectedRelease = $release; break }
}
if (!$binary) { Write-Error (T 'None'); exit 1 }

Write-Host "$(T 'Selected'): $($selectedRelease.tag_name)"
Write-Host "$(T 'Binary'): $($binary.name)"
Write-Host "$(T 'Runtime'): $($runtime.name)"

$thirdParty = Join-Path $root "third_party\llama.cpp"
$download = Join-Path $thirdParty "download"
$binaryZip = Join-Path $thirdParty "llama-cuda.zip"
$runtimeZip = Join-Path $thirdParty "cudart.zip"
New-Item -ItemType Directory -Force -Path $thirdParty | Out-Null
New-Item -ItemType Directory -Force -Path $binDir | Out-Null

Write-Host (T 'DownloadBinary')
Invoke-WebRequest -Uri $binary.browser_download_url -OutFile $binaryZip -UseBasicParsing
Write-Host (T 'DownloadRuntime')
Invoke-WebRequest -Uri $runtime.browser_download_url -OutFile $runtimeZip -UseBasicParsing

if (Test-Path $download) { Remove-Item $download -Recurse -Force }
$binaryExtract = Join-Path $download "binary"; $runtimeExtract = Join-Path $download "runtime"
New-Item -ItemType Directory -Force -Path $binaryExtract | Out-Null
New-Item -ItemType Directory -Force -Path $runtimeExtract | Out-Null
Expand-Archive -Path $binaryZip -DestinationPath $binaryExtract -Force
Expand-Archive -Path $runtimeZip -DestinationPath $runtimeExtract -Force

$found = Get-ChildItem $binaryExtract -Recurse -Filter "llama-server.exe" | Select-Object -First 1
if (!$found) { Write-Error (T 'Missing'); exit 1 }
Copy-Item $found.FullName $server -Force
Get-ChildItem $found.Directory.FullName -Filter "*.dll" -File | Copy-Item -Destination $binDir -Force
Get-ChildItem $runtimeExtract -Recurse -Filter "*.dll" -File | Copy-Item -Destination $binDir -Force

Write-Host ""
Write-Host "======================================"
Write-Host (T 'Success')
Write-Host "======================================"
Write-Host "$(T 'Server'): $server"
Write-Host ""
Write-Host (T 'NoToolkit')
Write-Host (T 'Driver')
