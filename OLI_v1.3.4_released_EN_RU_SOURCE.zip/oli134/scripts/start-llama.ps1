$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$server = Join-Path $root "third_party\llama.cpp\build\bin\Release\llama-server.exe"
$modelsDir = Join-Path $root "models"
$dataRoot = Join-Path $env:LOCALAPPDATA "OLI"
$settingsFile = Join-Path $dataRoot "settings.json"

if (!(Test-Path $server)) { & "$PSScriptRoot\install-oli.ps1" }
if (!(Test-Path $server)) { throw "llama-server.exe is still missing after installation." }
New-Item -ItemType Directory -Force -Path $modelsDir | Out-Null

$ctx = 4096; $gpu = 99; $threads = 8; $batch = 128; $ubatch = 64; $parallel = 1
if (Test-Path $settingsFile) {
    try {
        $s = Get-Content $settingsFile -Raw | ConvertFrom-Json
        if ($s.ContextSize) { $ctx = [int]$s.ContextSize }
        if ($s.GpuLayers -ge 0) { $gpu = [int]$s.GpuLayers }
        if ($s.CpuThreads -ge 1) { $threads = [int]$s.CpuThreads }
        if ($s.BatchSize -ge 1) { $batch = [int]$s.BatchSize }
        if ($s.UBatchSize -ge 1) { $ubatch = [int]$s.UBatchSize }
        if ($s.Parallel -ge 1) { $parallel = [int]$s.Parallel }
    } catch { }
}

Write-Host "Starting OLI llama-server: ctx=$ctx gpu=$gpu threads=$threads batch=$batch ubatch=$ubatch"
& $server `
  -hf "hugging-quants/Llama-3.2-3B-Instruct-Q4_K_M-GGUF:Q4_K_M" `
  --models-dir $modelsDir `
  --host 127.0.0.1 `
  --port 8080 `
  --ctx-size $ctx `
  --n-gpu-layers $gpu `
  --batch-size $batch `
  --ubatch-size $ubatch `
  --threads $threads `
  --parallel $parallel
