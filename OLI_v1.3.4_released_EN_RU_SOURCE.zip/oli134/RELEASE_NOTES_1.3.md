# OLI 1.3.0

- Settings GUI and live theme switching.
- Fast and Performance modes with visible mode indicator.
- Persistent user profile memory (name, age, interests, skills, projects).
- Current local date/time injected into every system context.
- Cache cleanup, AI Engine restart, diagnostics and destructive user-data reset.
- Settings persisted to `data/settings.json`.
- Mobile skeleton: `OLI.MobileGateway` and `Mobile/README.md`.
- Gateway binds to localhost only; Internet relay/TLS is intentionally not enabled yet.
