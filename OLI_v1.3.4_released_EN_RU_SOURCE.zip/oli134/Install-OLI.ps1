param(
    [switch]$Update,
    [ValidateSet('auto','ru','en')]
    [string]$Language = 'auto'
)
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$scripts = Join-Path $root "scripts"
$installerIcon = Join-Path $root "installer\OLI_Setup.ico"

function Resolve-Language([string]$value) {
    if ($value -eq 'ru') { return 'ru' }
    if ($value -eq 'en') { return 'en' }
    $culture = [System.Globalization.CultureInfo]::CurrentUICulture.TwoLetterISOLanguageName
    return $(if ($culture -eq 'en') { 'en' } else { 'ru' })
}
$Language = Resolve-Language $Language

$Strings = @{
    ru = @{
        Start='Запуск установки OLI...'; Icon='Иконка установщика'; DotNetMissing='Не удалось автоматически установить .NET 8 SDK.'; Winget='Устанавливаю .NET 8 SDK через winget...'; DotNetScript='Устанавливаю .NET 8 SDK через официальный скрипт...'; LlamaFail='Установка llama.cpp завершилась с ошибкой.'; BuildFail='Сборка OLI.exe завершилась с ошибкой.'; LauncherMissing='OLI-Launcher.exe не найден.'; Done='Установка OLI завершена.'
    }
    en = @{
        Start='Starting OLI installation...'; Icon='Installer icon'; DotNetMissing='Could not install the .NET 8 SDK automatically.'; Winget='Installing the .NET 8 SDK via winget...'; DotNetScript='Installing the .NET 8 SDK using the official script...'; LlamaFail='llama.cpp installation failed.'; BuildFail='OLI.exe build failed.'; LauncherMissing='OLI-Launcher.exe is missing.'; Done='OLI installation complete.'
    }
}
function T([string]$key) { return $Strings[$Language][$key] }

function Test-DotNet8Sdk {
    if (!(Get-Command dotnet -ErrorAction SilentlyContinue)) { return $false }
    $sdks = & dotnet --list-sdks 2>$null
    return ($null -ne ($sdks | Where-Object { $_ -match "^8\." }))
}

Write-Host (T 'Start')
if (Test-Path $installerIcon) { Write-Host "$(T 'Icon'): $installerIcon" }

if (-not $Update) {
    if (!(Test-DotNet8Sdk)) {
        $winget = Get-Command winget -ErrorAction SilentlyContinue
        if ($winget) {
            Write-Host (T 'Winget')
            winget install --id Microsoft.DotNet.SDK.8 -e --accept-package-agreements --accept-source-agreements
        } else {
            Write-Host (T 'DotNetScript')
            $installerScript = Join-Path $env:TEMP "dotnet-install.ps1"
            Invoke-WebRequest -Uri "https://dot.net/v1/dotnet-install.ps1" -OutFile $installerScript -UseBasicParsing
            $installDir = Join-Path $env:LOCALAPPDATA "Microsoft\dotnet"
            & $installerScript -Channel 8.0 -InstallDir $installDir
            $env:PATH = "$installDir;$env:PATH"
        }
        $env:PATH = [Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [Environment]::GetEnvironmentVariable("PATH", "User")
        if (!(Test-DotNet8Sdk)) { throw (T 'DotNetMissing') }
    }

    & (Join-Path $scripts "install-oli.ps1") -Language $Language
    if ($LASTEXITCODE -ne 0) { throw (T 'LlamaFail') }
}

& (Join-Path $scripts "build-oli.ps1") -Language $Language
if ($LASTEXITCODE -ne 0) { throw (T 'BuildFail') }

$launcher = Join-Path $root "OLI-Launcher.exe"
if (!(Test-Path $launcher)) { throw (T 'LauncherMissing') }

$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath("Desktop")
$startMenu = Join-Path ([Environment]::GetFolderPath("Programs")) "OLI"
New-Item -ItemType Directory -Force -Path $startMenu | Out-Null

foreach ($dir in @($desktop, $startMenu)) {
    $lnk = $shell.CreateShortcut((Join-Path $dir "OLI.lnk"))
    $lnk.TargetPath = $launcher
    $lnk.WorkingDirectory = $root
    $exe = Join-Path $root "dist\OLI.exe"
    if (Test-Path $exe) { $lnk.IconLocation = "$exe,0" }
    $lnk.Description = if ($Language -eq 'en') { 'OLI - local AI assistant' } else { 'OLI — локальный ИИ-помощник' }
    $lnk.Save()
}

Write-Host (T 'Done')
