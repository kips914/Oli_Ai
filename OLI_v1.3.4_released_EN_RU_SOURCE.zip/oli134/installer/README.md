# OLI Setup icon

`OLI_Setup.ico` is the installer icon extracted from the approved OLI artwork.

For a compiled `OLI_Setup.exe`, use this ICO as the executable resource with the chosen PowerShell-to-EXE packager.
The main WPF application already embeds `OLI.Client/Assets/OLI.ico` through `ApplicationIcon`.
