# OLI 1.3.3_released

## GitHub Updates
- Added GitHub Releases update checker.
- Checks the latest non-prerelease GitHub Release and compares semantic versions.
- Optional automatic check on application startup.
- Manual check is available in Settings.
- Update notifications open the GitHub release page; the existing GUI installer/updater remains responsible for replacing application files.
- Repository URL is configurable in Settings.

## Versioning
- VERSION: `OLI 1.3.3_released`
- Assembly/File version: `1.3.3.0`
- Informational version: `1.3.3_released`
