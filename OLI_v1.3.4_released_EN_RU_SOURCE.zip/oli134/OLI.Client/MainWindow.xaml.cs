using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using OLI.Core;
using OLI.Engine;
using OLI.Memory;
using OLI.Web;

namespace OLI.Client;

public partial class MainWindow : Window
{
    // General lookup, entire reply must be exactly this one line: "OLI_SEARCH: <query>".
    private static readonly Regex SearchTokenRx = new(
        @"^\s*OLI_SEARCH:\s*(?<query>.+?)\s*$",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    // Page-open request, one per line: "OLI_OPEN: <url>". The WHOLE reply must consist
    // only of such lines (checked in TryParseOpenUrls) for it to count as this protocol.
    private static readonly Regex OpenLineRx = new(
        @"^\s*OLI_OPEN:\s*(?<url>\S+)\s*$",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    // Trailing memory annotation(s), can appear anywhere in an otherwise normal answer:
    // "OLI_REMEMBER: <fact>" on its own line. Stripped from what the user sees.
    private static readonly Regex RememberLineRx = new(
        @"^[ \t]*OLI_REMEMBER:[ \t]*(?<fact>.+?)[ \t]*$",
        RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);

    // Hard cap on search/open round-trips per user message, so a confused model can't
    // loop forever. Must match the number promised in Persona's OLI_OPEN instructions
    // for the per-request page cap.
    private const int MaxProtocolSteps = 3;
    private const int MaxOpenPages = Persona.MaxOpenPages;

    private readonly OliSettings _settings = SettingsStore.Load();
    private readonly LlamaClient _llama;
    private readonly WebSearch _web = new();
    private readonly MemoryStore _memory;
    private readonly UserProfileStore _profile;
    private readonly ContextBuilder _context = new();
    private readonly List<ChatMessage> _history = [];
    private readonly ObservableCollection<ChatMessage> _display = [];
    private readonly ObservableCollection<AllowedSite> _allowedSites;
    private readonly GitHubUpdateService _updateService = new();

    public MainWindow()
    {
        InitializeComponent();
        AppPaths.EnsureDirectories();
        Localization.Initialize(_settings.Language);
        App.ApplyTheme(_settings.Theme);
        UiLocalization.ApplyMain(this);
        Localization.LanguageChanged += OnLanguageChanged;
        _settings.MaxTokens = _settings.Mode == GenerationMode.Performance ? _settings.PerformanceMaxTokens : _settings.FastMaxTokens;
        _llama = new LlamaClient(_settings.LlamaBaseUrl);
        _memory = new MemoryStore(AppPaths.MemoryFile);
        _profile = new UserProfileStore(AppPaths.ProfileFile);
        ChatList.ItemsSource = _display;
        ModeText.Text = _settings.Mode == GenerationMode.Performance ? "🧠 PERFORMANCE" : "⚡ FAST";
        _allowedSites = new ObservableCollection<AllowedSite>(_settings.AllowedSites);
        SitesList.ItemsSource = _allowedSites;
        WebSearchMasterToggle.IsChecked = _settings.WebSearchEnabled;
        OliLog.EntryAdded += OnLogEntry;
        foreach (var e in OliLog.Snapshot()) AddConsoleEntry(e);
        Loaded += async (_, _) => { await RefreshStatusAsync(); _ = CheckForUpdatesOnStartupAsync(); };
        Closed += (_, _) => { Localization.LanguageChanged -= OnLanguageChanged; OliLog.EntryAdded -= OnLogEntry; _llama.Dispose(); _updateService.Dispose(); };
    }

    private void OnLanguageChanged(object? sender, EventArgs e) => Dispatcher.Invoke(() => UiLocalization.ApplyMain(this));
    public string CurrentModeText() => _settings.Mode == GenerationMode.Performance ? Localization.T("mode.performance.short") : Localization.T("mode.fast.short");
    private void OnLogEntry(OliLogEntry entry) => Dispatcher.Invoke(() => AddConsoleEntry(entry));
    private void AddConsoleEntry(OliLogEntry entry)
    {
        ConsoleList.Items.Add($"[{entry.Time:HH:mm:ss}] {entry.Level.ToString().ToUpperInvariant(),-7} {entry.Source,-10} {entry.Message}");
        if (ConsoleAutoScroll.IsChecked == true && ConsoleList.Items.Count > 0) ConsoleList.ScrollIntoView(ConsoleList.Items[^1]);
    }
    private void ClearConsole_Click(object sender, RoutedEventArgs e) => ConsoleList.Items.Clear();
    private void CopyConsole_Click(object sender, RoutedEventArgs e)
    {
        Clipboard.SetText(string.Join(Environment.NewLine, ConsoleList.Items.Cast<object>()));
    }
    private void MainTabs_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (!IsLoaded || e.Source != MainTabs) return;
        InputBox.Visibility = MainTabs.SelectedIndex == 0 ? Visibility.Visible : Visibility.Collapsed;
        SendButton.Visibility = MainTabs.SelectedIndex == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private async Task RefreshStatusAsync()
    {
        OliLog.Info("ENGINE", Localization.T("console.engineCheck"));
        var alive = await _llama.IsAliveAsync();
        StatusText.Text = alive ? Localization.T("status.connected") : Localization.T("status.serverMissing");
        StatusDot.Fill = (Brush)Application.Current.Resources[alive ? "OnlineBrush" : "OfflineBrush"];
        if (alive) OliLog.Info("ENGINE", Localization.T("console.serverResponds")); else OliLog.Warning("ENGINE", Localization.T("console.serverUnavailable"));
    }


    private async Task CheckForUpdatesOnStartupAsync()
    {
        if (!_settings.CheckForUpdatesOnStartup || _settings.GitHubRepositoryUrl.Contains("REPLACE_ME", StringComparison.OrdinalIgnoreCase))
        {
            OliLog.Debug("UPDATE", Localization.Current == OliLanguage.English ? "GitHub update check is disabled or the repository is not configured" : "Проверка GitHub обновлений отключена или репозиторий не настроен");
            return;
        }

        try
        {
            var result = await _updateService.CheckAsync(_settings.GitHubRepositoryUrl);
            if (!result.Success)
            {
                OliLog.Warning("UPDATE", result.Error ?? Localization.T("update.error", "unknown"));
                return;
            }

            if (!result.UpdateAvailable)
            {
                OliLog.Info("UPDATE", Localization.T("update.latest", result.CurrentVersion));
                return;
            }

            OliLog.Info("UPDATE", Localization.T("update.available", result.LatestVersion));
            Dispatcher.Invoke(() =>
            {
                var answer = MessageBox.Show(this,
                    $"{Localization.T("update.startupAvailable", result.LatestVersion)}\n\nCurrent: {result.CurrentVersion}\n\n{Localization.T("update.startupPrompt")}",
                    Localization.T("update.title"), MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (answer == MessageBoxResult.Yes && result.Release is not null)
                    Process.Start(new ProcessStartInfo(result.Release.HtmlUrl) { UseShellExecute = true });
            });
        }
        catch (Exception ex)
        {
            OliLog.Warning("UPDATE", Localization.T("update.error", ex.Message));
        }
    }

    private void SettingsButton_Click(object sender, RoutedEventArgs e) => SettingsPopup.IsOpen = !SettingsPopup.IsOpen;
    private void OpenFullSettings_Click(object sender, RoutedEventArgs e)
    {
        SettingsPopup.IsOpen = false;
        var w = new SettingsWindow(_settings) { Owner = this };
        if (w.ShowDialog() == true)
        {
            _settings.MaxTokens = _settings.Mode == GenerationMode.Performance ? _settings.PerformanceMaxTokens : _settings.FastMaxTokens;
            ModeText.Text = _settings.Mode == GenerationMode.Performance ? "🧠 PERFORMANCE" : "⚡ FAST";
            SettingsStore.Save(_settings);
            if (w.RestartRequested) RestartApplication();
        }
    }
    private void RestartApplication()
    {
        OliLog.Info("APP", Localization.T("console.restart"));
        var exe = Environment.ProcessPath;
        if (!string.IsNullOrWhiteSpace(exe)) System.Diagnostics.Process.Start(exe);
        Application.Current.Shutdown();
    }
    private void InputBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter || Keyboard.Modifiers == ModifierKeys.Shift) return;
        e.Handled = true; Send_Click(sender, new RoutedEventArgs());
    }

    private async void Send_Click(object sender, RoutedEventArgs e)
    {
        var text = InputBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(text)) return;
        SendButton.IsEnabled = false; InputBox.IsEnabled = false; InputBox.Clear();
        _display.Add(new ChatMessage("user", text)); ScrollToEnd();
        OliLog.Info("CHAT", $"User request: {Math.Min(text.Length, 120)} chars");
        try
        {
            _profile.LearnFrom(text);
            var memoryContext = _memory.BuildContext();
            var profileContext = _profile.Profile.BuildContext();
            var userTurn = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(profileContext)) userTurn.AppendLine(Localization.T("profile.label") + "\n" + profileContext + "\n");
            if (!string.IsNullOrWhiteSpace(memoryContext)) userTurn.AppendLine(Localization.T("memory.label") + "\n" + memoryContext + "\n");
            userTurn.Append(text);
            _history.Add(new ChatMessage("user", userTurn.ToString()));

            var webSearchEnabled = WebSearchMasterToggle.IsChecked == true;
            var systemPrompt = Persona.BuildSystemPrompt(_allowedSites, webSearchEnabled, profileContext, _settings.Mode);

            StatusText.Text = Localization.T("status.thinking");
            var answer = await AskModelAsync(systemPrompt);

            // Bounded search/open loop: the model can ask to search, then ask to open
            // specific pages from those results, possibly repeating a couple of times,
            // before giving its real answer. We never let this run unbounded.
            var exhausted = false;
            for (var step = 0; webSearchEnabled && step < MaxProtocolSteps; step++)
            {
                var trimmed = answer.Trim();
                var searchMatch = SearchTokenRx.Match(trimmed);
                var openUrls = TryParseOpenUrls(trimmed);

                if (searchMatch.Success)
                {
                    _history.Add(new ChatMessage("assistant", answer));
                    var query = searchMatch.Groups["query"].Value;
                    var domains = _allowedSites.Where(s => s.IsEnabled).Select(s => s.Domain).ToList();
                    _display.Add(new ChatMessage("system", $"{Localization.T("searching", query)}")); ScrollToEnd();
                    StatusText.Text = Localization.T("status.searching");
                    var resultsBlock = await BuildSearchResultsBlockAsync(query, domains);
                    _history.Add(new ChatMessage("user", resultsBlock));
                }
                else if (openUrls.Count > 0)
                {
                    _history.Add(new ChatMessage("assistant", answer));
                    var domains = _allowedSites.Where(s => s.IsEnabled).Select(s => s.Domain).ToList();
                    var label = openUrls.Count == 1 ? Localization.T("opening.one", openUrls[0]) : Localization.T("opening.many", openUrls.Count);
                    _display.Add(new ChatMessage("system", label)); ScrollToEnd();
                    StatusText.Text = Localization.T("status.reading");
                    var pagesBlock = await BuildOpenPagesBlockAsync(openUrls, domains);
                    _history.Add(new ChatMessage("user", pagesBlock));
                }
                else
                {
                    break; // this looks like a real answer — stop the loop
                }

                StatusText.Text = Localization.T("status.thinking");
                answer = await AskModelAsync(systemPrompt);

                if (step == MaxProtocolSteps - 1)
                {
                    var stillProtocol = SearchTokenRx.IsMatch(answer.Trim()) || TryParseOpenUrls(answer.Trim()).Count > 0;
                    if (stillProtocol) exhausted = true;
                }
            }

            string finalAnswer;
            if (exhausted)
            {
                finalAnswer = Localization.T("protocol.exhausted");
                OliLog.Warning("CHAT", "Protocol step limit reached without a final answer");
            }
            else
            {
                var (clean, facts) = ExtractMemoryFacts(answer);
                finalAnswer = clean;
                foreach (var fact in facts)
                {
                    await _memory.AddAsync(fact);
                    OliLog.Info("MEMORY", $"Saved: {fact}");
                }
            }

            _history.Add(new ChatMessage("assistant", finalAnswer));
            _display.Add(new ChatMessage("assistant", finalAnswer));
            ScrollToEnd(); StatusText.Text = Localization.T("status.ready");
        }
        catch (Exception ex)
        {
            OliLog.Error("CHAT", ex.ToString());
            _display.Add(new ChatMessage("assistant", Localization.T("error.prefix", ex.Message))); ScrollToEnd(); StatusText.Text = Localization.T("status.error");
        }
        finally { SendButton.IsEnabled = true; InputBox.IsEnabled = true; InputBox.Focus(); }
    }

    /// <summary>
    /// True protocol match only when EVERY non-empty line of the trimmed reply is an
    /// "OLI_OPEN: &lt;url&gt;" line — a stray mention elsewhere doesn't count, same rule
    /// as OLI_SEARCH needing to be the reply's entire content.
    /// </summary>
    private static List<string> TryParseOpenUrls(string trimmedAnswer)
    {
        var lines = trimmedAnswer
            .Split('\n')
            .Select(l => l.Trim())
            .Where(l => l.Length > 0)
            .ToList();

        if (lines.Count == 0) return [];
        if (!lines.All(l => OpenLineRx.IsMatch(l))) return [];

        return lines.Select(l => OpenLineRx.Match(l).Groups["url"].Value).Take(MaxOpenPages).ToList();
    }

    /// <summary>
    /// Pulls every "OLI_REMEMBER: &lt;fact&gt;" line out of the answer (they can be
    /// mixed in with a normal reply, unlike the exclusive search/open tokens) and
    /// returns the answer with those lines removed, plus the extracted facts.
    /// </summary>
    private static (string Clean, List<string> Facts) ExtractMemoryFacts(string answer)
    {
        var facts = new List<string>();
        var clean = RememberLineRx.Replace(answer, m =>
        {
            var fact = m.Groups["fact"].Value.Trim();
            if (fact.Length > 0) facts.Add(fact);
            return "";
        });
        clean = Regex.Replace(clean, @"\n{3,}", "\n\n").Trim();
        if (clean.Length == 0 && facts.Count > 0) clean = Localization.T("remembered");
        return (clean, facts);
    }

    private async Task<string> BuildSearchResultsBlockAsync(string query, List<string> enabledDomains)
    {
        try
        {
            var results = enabledDomains.Count > 0 ? await _web.SearchAsync(query, enabledDomains, _settings.WebSearchResultLimit) : [];
            if (results.Count == 0) return Localization.T("search.none", query);
            var sb = new StringBuilder(); sb.AppendLine(Localization.T("search.block", query));
            foreach (var r in results) { sb.AppendLine($"- {r.Title}"); if (!string.IsNullOrWhiteSpace(r.Snippet)) sb.AppendLine($"  {r.Snippet}"); sb.AppendLine($"  Источник: {r.Url}"); }
            sb.AppendLine(Localization.T("search.followup"));
            return sb.ToString();
        }
        catch (WebSearchException ex) { OliLog.Warning("WEB", ex.Message); return $"Поиск недоступен: {ex.Message}. Ответь без выдумывания фактов."; }
    }

    private async Task<string> BuildOpenPagesBlockAsync(List<string> urls, List<string> allowedDomains)
    {
        var sb = new StringBuilder();
        sb.AppendLine(Localization.T("page.block"));

        foreach (var url in urls)
        {
            sb.AppendLine();
            sb.AppendLine($"### {url}");
            try
            {
                var pageText = await _web.FetchPageTextAsync(url, allowedDomains, maxChars: 2000);
                sb.AppendLine(pageText.Length > 0 ? pageText : Localization.T("page.empty"));
            }
            catch (WebSearchException ex)
            {
                OliLog.Warning("WEB", $"{url}: {ex.Message}");
                sb.AppendLine(Localization.T("page.failed", ex.Message));
            }
        }

        sb.AppendLine();
        sb.AppendLine(Localization.T("page.followup"));
        return sb.ToString();
    }

    private Task<string> AskModelAsync(string systemPrompt)
    {
        var messages = _context.Build(_history, systemPrompt, _settings.ContextSize);
        OliLog.Debug("CONTEXT", $"messages={messages.Count}, contextLimit={_settings.ContextSize}");
        return _llama.ChatAsync(messages, _settings.Model, _settings.Temperature, _settings.MaxTokens);
    }
    private void ScrollToEnd() => Dispatcher.InvokeAsync(() => ChatScroll.ScrollToEnd(), System.Windows.Threading.DispatcherPriority.Background);
}
