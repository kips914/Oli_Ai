using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using OLI.Core;

namespace OLI.Client;

public partial class SettingsWindow : Window
{
    private readonly OliSettings _settings;
    private bool _initializing;
    private OliLanguage _selectedLanguage;
    public bool RestartRequested { get; private set; }

    public SettingsWindow(OliSettings settings)
    {
        InitializeComponent();
        _settings = settings;
        _selectedLanguage = settings.Language;
        _initializing = true;
        FastMode.IsChecked = settings.Mode == GenerationMode.Fast;
        PerformanceMode.IsChecked = settings.Mode == GenerationMode.Performance;
        ContextSlider.Value = settings.ContextSize;
        ThreadsSlider.Value = settings.CpuThreads;
        GpuSlider.Value = settings.GpuLayers;
        CheckUpdatesStartup.IsChecked = settings.CheckForUpdatesOnStartup;
        GitHubRepositoryBox.Text = settings.GitHubRepositoryUrl;
        LanguageCombo.Items.Add(new KeyValuePair<OliLanguage,string>(OliLanguage.Auto, Localization.T("language.auto")));
        LanguageCombo.Items.Add(new KeyValuePair<OliLanguage,string>(OliLanguage.Russian, Localization.T("language.ru")));
        LanguageCombo.Items.Add(new KeyValuePair<OliLanguage,string>(OliLanguage.English, Localization.T("language.en")));
        LanguageCombo.SelectedValue = _selectedLanguage;
        UpdateLabels();
        UiLocalization.ApplySettings(this);
        LanguageCombo.SelectedValue = _selectedLanguage;
        _initializing = false;
        Localization.LanguageChanged += OnLanguageChanged;
        Closed += (_, _) => Localization.LanguageChanged -= OnLanguageChanged;
    }

    private void OnLanguageChanged(object? sender, EventArgs e)
    {
        _initializing = true;
        UiLocalization.ApplySettings(this);
        LanguageCombo.SelectedValue = _selectedLanguage;
        _initializing = false;
        UpdateLabels();
    }

    void UpdateLabels(){ ContextValue.Text=$"{(int)ContextSlider.Value} {(_selectedLanguage == OliLanguage.English || Localization.Current == OliLanguage.English ? "tokens" : "токенов")}"; ThreadsValue.Text=$"{(int)ThreadsSlider.Value}"; GpuValue.Text=$"{(int)GpuSlider.Value}"; }
    void Mode_Checked(object s,RoutedEventArgs e){ if(IsLoaded) _settings.Mode=PerformanceMode.IsChecked==true?GenerationMode.Performance:GenerationMode.Fast; }
    void Dark_Click(object s,RoutedEventArgs e){_settings.Theme=OliTheme.Dark; App.ApplyTheme(OliTheme.Dark);}
    void Light_Click(object s,RoutedEventArgs e){_settings.Theme=OliTheme.Light; App.ApplyTheme(OliTheme.Light);}
    void System_Click(object s,RoutedEventArgs e){_settings.Theme=OliTheme.System; App.ApplyTheme(OliTheme.System);}
    void LanguageCombo_SelectionChanged(object s, SelectionChangedEventArgs e)
    {
        if (_initializing || LanguageCombo.SelectedValue is not OliLanguage lang) return;
        _selectedLanguage = lang;
        _initializing = true;
        Localization.Initialize(lang);
        UiLocalization.ApplySettings(this);
        LanguageCombo.SelectedValue = lang;
        _initializing = false;
        UpdateLabels();
    }
    void ClearCache_Click(object s,RoutedEventArgs e){SettingsStore.ClearCache(); MessageBox.Show(this,Localization.T("cache.cleared"),"OLI",MessageBoxButton.OK,MessageBoxImage.Information);}
    void Restart_Click(object s,RoutedEventArgs e){RestartRequested=true; DialogResult=true;}
    void Diagnostics_Click(object s,RoutedEventArgs e){MessageBox.Show(this,$"OLI {AppVersion.Current}\nData: {AppPaths.DataRoot}\nGPU layers: {(int)GpuSlider.Value}\nContext: {(int)ContextSlider.Value}\nCPU threads: {(int)ThreadsSlider.Value}\nMode: {_settings.Mode}\nllama.cpp: {_settings.LlamaBaseUrl}\nGitHub: {_settings.GitHubRepositoryUrl}",Localization.T("diagnostics.title"),MessageBoxButton.OK,MessageBoxImage.Information);}
    void Reset_Click(object s,RoutedEventArgs e){if(MessageBox.Show(this,Localization.T("reset.confirm"),Localization.T("confirm"),MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes){SettingsStore.ResetUserData();RestartRequested=true;DialogResult=true;}}

    private async void CheckUpdates_Click(object sender, RoutedEventArgs e)
    {
        UpdateStatusText.Text = Localization.T("update.checking");
        try
        {
            using var service = new GitHubUpdateService();
            var result = await service.CheckAsync(GitHubRepositoryBox.Text.Trim());
            if (!result.Success){ UpdateStatusText.Text = $"⚠ {result.Error}"; return; }
            if (!result.UpdateAvailable){ UpdateStatusText.Text = Localization.T("update.latest", result.CurrentVersion); return; }
            UpdateStatusText.Text = Localization.T("update.available", result.LatestVersion);
            if (MessageBox.Show(this, $"{Localization.T("update.available", result.LatestVersion)}\n\nCurrent: {result.CurrentVersion}\n\n{Localization.T("update.openPrompt")}", Localization.T("update.title"), MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes && result.Release is not null)
                Process.Start(new ProcessStartInfo(result.Release.HtmlUrl) { UseShellExecute = true });
        }
        catch (Exception ex){ UpdateStatusText.Text = Localization.T("update.error", ex.Message); }
    }

    void Save_Click(object s,RoutedEventArgs e){
        _settings.ContextSize=(int)ContextSlider.Value;
        _settings.CpuThreads=(int)ThreadsSlider.Value;
        _settings.GpuLayers=(int)GpuSlider.Value;
        _settings.MaxTokens=_settings.Mode==GenerationMode.Performance?_settings.PerformanceMaxTokens:_settings.FastMaxTokens;
        _settings.CheckForUpdatesOnStartup = CheckUpdatesStartup.IsChecked == true;
        _settings.GitHubRepositoryUrl = GitHubRepositoryBox.Text.Trim();
        _settings.Language = _selectedLanguage;
        Localization.Initialize(_selectedLanguage);
        SettingsStore.Save(_settings);
        DialogResult=true;
    }
    void Cancel_Click(object s,RoutedEventArgs e){DialogResult=false;}
}
