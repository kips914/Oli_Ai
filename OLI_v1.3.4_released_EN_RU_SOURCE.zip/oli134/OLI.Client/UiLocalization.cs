using System.Windows;
using OLI.Core;

namespace OLI.Client;

public static class UiLocalization
{
    public static void ApplyMain(MainWindow w)
    {
        w.Title = "OLI";
        w.TaglineText.Text = Localization.T("app.tagline");
        w.SettingsButton.ToolTip = Localization.T("web.title");
        w.WebTitleText.Text = Localization.T("web.title");
        w.WebDescriptionText.Text = Localization.T("web.description");
        w.WebSearchMasterToggle.Content = Localization.T("web.allow");
        w.AllowedSitesText.Text = Localization.T("web.allowedSites");
        w.FullSettingsButton.Content = Localization.T("settings.full");
        w.ChatTab.Header = Localization.T("chat.tab");
        w.ConsoleTab.Header = Localization.T("console.tab");
        w.ClearConsoleButton.Content = Localization.T("console.clear");
        w.CopyConsoleButton.Content = Localization.T("console.copy");
        w.ConsoleAutoScroll.Content = Localization.T("console.autoscroll");
        w.SendButton.Content = Localization.T("send");
        w.InputHelpText.Text = Localization.T("input.help");
        w.ModeText.Text = w.CurrentModeText();
        if (!w.IsLoaded) w.StatusText.Text = Localization.T("status.starting");
    }

    public static void ApplySettings(SettingsWindow w)
    {
        w.Title = Localization.T("settings.title");
        w.SettingsTitleText.Text = Localization.T("settings.title");
        w.AppearanceText.Text = Localization.T("appearance");
        w.DarkButton.Content = Localization.T("theme.dark");
        w.LightButton.Content = Localization.T("theme.light");
        w.SystemButton.Content = Localization.T("theme.system");
        w.AiModeText.Text = Localization.T("ai.mode");
        w.FastMode.Content = Localization.T("mode.fast");
        w.PerformanceMode.Content = Localization.T("mode.performance");
        w.PerformanceText.Text = Localization.T("performance");
        w.ContextText.Text = Localization.T("context");
        w.ThreadsText.Text = Localization.T("cpuThreads");
        w.GpuText.Text = Localization.T("gpuLayers");
        w.LanguageText.Text = Localization.T("language");
        w.UpdatesText.Text = Localization.T("updates");
        w.CheckUpdatesStartup.Content = Localization.T("updates.startup");
        w.GitHubText.Text = Localization.T("updates.repo");
        w.CheckUpdatesButton.Content = Localization.T("updates.check");
        w.MaintenanceText.Text = Localization.T("maintenance");
        w.ClearCacheButton.Content = Localization.T("cache.clear");
        w.RestartButton.Content = Localization.T("engine.restart");
        w.DiagnosticsButton.Content = Localization.T("diagnostics");
        w.ResetTitleText.Text = Localization.T("reset.title");
        w.ResetDescriptionText.Text = Localization.T("reset.description");
        w.ResetButton.Content = Localization.T("reset.button");
        w.MobileTitleText.Text = Localization.T("mobile.title");
        w.MobileDescriptionText.Text = Localization.T("mobile.description");
        w.CancelButton.Content = Localization.T("cancel");
        w.SaveButton.Content = Localization.T("save");
        w.LanguageCombo.Items.Clear();
        w.LanguageCombo.Items.Add(new KeyValuePair<OliLanguage,string>(OliLanguage.Auto, Localization.T("language.auto")));
        w.LanguageCombo.Items.Add(new KeyValuePair<OliLanguage,string>(OliLanguage.Russian, Localization.T("language.ru")));
        w.LanguageCombo.Items.Add(new KeyValuePair<OliLanguage,string>(OliLanguage.English, Localization.T("language.en")));
    }
}
