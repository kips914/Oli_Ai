using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace OLI.Client;

/// <summary>
/// user -> right, assistant -> left, system (search-status notes) -> center.
/// </summary>
public sealed class RoleToAlignmentConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => (value as string) switch
        {
            "user" => HorizontalAlignment.Right,
            "system" => HorizontalAlignment.Center,
            _ => HorizontalAlignment.Left,
        };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>Small label above each bubble: "Вы" for the user, "OLI" for the assistant, none for status notes.</summary>
public sealed class RoleToLabelConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => (value as string) switch
        {
            "user" => "Вы",
            "assistant" => "OLI",
            _ => "",
        };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
