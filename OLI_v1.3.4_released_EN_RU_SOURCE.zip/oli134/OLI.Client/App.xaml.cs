using System.Windows;
using System.Windows.Media;
using OLI.Core;

namespace OLI.Client;
public partial class App : Application
{
    public static void ApplyTheme(OliTheme theme)
    {
        var dark = theme == OliTheme.Dark || (theme == OliTheme.System && SystemParameters.HighContrast == false);
        var r = Current.Resources;
        Set(r,"BgWindowBrush", dark ? "#0F1115" : "#F4F5F8");
        Set(r,"BgPanelBrush", dark ? "#171A21" : "#FFFFFF");
        Set(r,"BgInputBrush", dark ? "#1E2129" : "#EEF0F5");
        Set(r,"BorderBrush2", dark ? "#262A35" : "#D9DDE7");
        Set(r,"TextPrimaryBrush", dark ? "#E9E9F1" : "#20232B");
        Set(r,"TextMutedBrush", dark ? "#8A8FA3" : "#687084");
        Set(r,"BubbleAssistantBrush", dark ? "#242833" : "#E7EAF1");
    }
    static void Set(ResourceDictionary r,string key,string hex) => r[key]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
}
